import boto3
import time

def check_ec2(instance_id):
    ec2 = boto3.client('ec2')
    response = ec2.describe_instances(InstanceIds=[instance_id])
    instance_status = response['Reservations'][0]['Instances'][0]['State']['Name']
    return instance_status == 'running'

def start_ec2_if_not_running(instance_id):
    if not check_ec2(instance_id):
        print("EC2 instance is not running. Starting it up...")
        ec2 = boto3.client('ec2')
        ec2.start_instances(InstanceIds=[instance_id])
    else:
        print("EC2 instance is already running.")

def lambda_handler(event, context):
    instance_id = "i-0449e6d1aa478c8c0"  # Replace INSTANCE_ID with your EC2 instance ID
    start_ec2_if_not_running(instance_id)

    # Wait until the EC2 instance is running
    while True:
        if check_ec2(instance_id):
            print("EC2 instance is now running.")
            break
        else:
            print("Waiting for EC2 instance to start...")
            time.sleep(10)  # Adjust the sleep time as needed
